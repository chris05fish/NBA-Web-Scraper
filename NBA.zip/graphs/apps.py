from django.apps import AppConfig


class GraphsConfig(AppConfig):
    name = 'graphs'
